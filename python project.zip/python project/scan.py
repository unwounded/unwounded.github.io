###The following program conducts a comprehensive port scan
# on an inputted web server ip address.  This web scan utilizes
# nmap, dirb, and various python imports such as socket to find
# open ports and attempt to snoop and search their contents.
# The webserver header, extensions, version, process name, and product ID
# are found and if applicable a nessus web scan is conducted after all this 
# information is gathered. Bryce A. Place 2301241@uad.ac.uk

import nmap,os,socket,subprocess,requests,json,ipaddress
from rich import print


# scanner variable that utilizes python nmap import and opens a port scanner.
scanner = nmap.PortScanner()

# prompts user to input IP address
target = input("IP Address: ")
true = True
# try expression to check if the IP address is valid, exits program if invalid.
try:
	ipaddress.IPv4Address(target)
	true = True
except ipaddress.AddressValueError:
	true = False
if not true:
	print("Invalid input.")
	exit(1)


###open port test
print("Initial Port Scan: ")
# range of potential open ports being examined
ports = range(1,9999)
# open port array
open_ports = []
# socket variable utilizing socket import, attempts to connect to get a connection with
# the web server. Adds port to open port array if connetion is established.
sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
for port in ports:
	try:
		sock.connect((target,port))
		open_ports.append(port)
	except:
		pass
sock.close()
# print open port list
for port in open_ports:
	print(f"[+] Port {port} is open.")
###open port test


###banner test
# check if there are any open ports before Banner testing
if (len(open_ports) > 0):
	print("Banner Grab Test: ")
	# socket construction
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	for port in open_ports:
		try:
			# check if web server is up and giving 200 signal.
			# print the banner after tcp port is confirmed open.
			sock.connect((target, port))
			sock.send(b'200 OK\r\n')
			banner = str(sock.recv(256), 'ascii')
			print("[+] {port}/tcp is open")
			print("[+] banner:")
			print(banner)
		except socket.error as e:
			# if error print if port is filtered or closed whether it times out 
			# or is invalid.
			if 'timed out' in str(e):
				error = 'filtered'
			else:
				error = 'closed'
			print("[-] {port}/tcp is {error}")
	# close socket regardless
	sock.close()
###banner test

###nmap test
print("Nmap Scan Test: ")
# nmap port scanner object, creates an nmap scan with specified parameters.
scanner.scan(target, arguments='-sS -sV -p-')
# write namp scan results into a file, printing the results to the command line.
with open("nmapscanresult.txt", "w") as file:
	file.write("Nmap scan results: \n")
	# for hosts grabbed by the nmap scan
	for host in scanner.all_hosts():
		file.write(f"Host:  {host} \n")
		file.write(f"State: {scanner[host].state()} \n")
		# for protocol in nmap scan 
		for proto in scanner[host].all_protocols():
			file.write(f"Protocol: {proto}\n")
			ports = scanner[host][proto].keys()
			# write nmap results into file.
			for port in ports:
				file.write(f"Port: {port}, State: {scanner[host][proto][port]['state']} \n")
				file.write(f"Service: {scanner[host][proto][port]['name']} \n")
				file.write(f"Product: {scanner[host][proto][port]['product']} \n")
				file.write(f"Version: {scanner[host][proto][port]['version']} \n")
with open("nmapscanresult.txt", "r") as file:
	print(file.read())
###nmap test
	
	
###dirb test
# confirm there is an open tcp port to test
if (len(open_ports) > 0):
	print("dirb Scan Test: ")
	# establish dirb file path
	dirb_dir = f"reports/dirb/{target}"
	# establish dirb.txt file
	dirb_file = os.path.join(dirb_dir, "dirb.txt")

	# create directory if doesn't exist
	if not os.path.exists(dirb_dir):
		os.makedirs(dirb_dir)
		
	print(f"Scanning target: {target}")
	# write dirb scan results into file
	with open("dirbscanresult.txt", "w") as file:
		for port in open_ports:
			url = f"http://{target}:{port}"
			result = subprocess.run(['dirb', url, '-o', dirb_file], capture_output=True, text=True)
			file.write(f"{result.stdout}")
	# read dirb file scan results
	with open("dirbscanresult.txt", "r") as file:
		print(file.read())
###dirb test


###nessus test
print("Nessus API Scan Test: ")
try:
	# prompt user to input their nessus IP
	nessus = input("Enter your Nessus IP Address")
	url = f"https://{nessus}:8834"
	# commented out akey and skey variables that should be replaced by user if inputting
	# keys is far too tedious.  Command lines are hard to copy long strings.
	#akey = f"input your accessKey"
	akey = input("Enter your accessKey: ")
	#skey = f"input your secretKey"
	skey = input("Enter your secretKey: ")
	scans = "/scans"
	# nessus API header
	headers = {
		"X-ApiKeys": f"accessKey={akey}; secretKey={skey}",
		"Content-Type": "application/json"
	}
	# basis web scan data being inputted into the API
	data = {
		"uuid": "731a8e52-3ea6-a291-ec0a-d2ff0619c19d7bd788d6be818b65",
		"settings": {
			"name": "scan",
			"enabled": True,
			"text_target": f"https://{target}"
		}
	}
	# the actual nessus test request
	response = requests.post(f"{url}{scans}", headers=headers, json=data, verify=False)

	# prompt user if test was a success, inform user if test failed with reason.
	if response.status_code == 200:
		print("[+] Success!")
		print("Response: ", response.json())
	else:
		print("[-] Failed!")
		print("Response Status Code:", response.status_code)
		print("Response Text:", response.text)
except:
	#  if user never inputted nessus IP, prompt user with message.
	print("Please input your Nessus information to get this to work!")
###nessus test



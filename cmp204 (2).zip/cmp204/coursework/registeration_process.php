<?php
	session_start();
	error_reporting(E_ALL);
	ini_set('display_errors', 1);

	include_once "db_config.php";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
		$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
		$password = password_hash(filter_input(INPUT_POST, 'password', FILTER_UNSAFE_RAW), PASSWORD_DEFAULT); // Use password_hash for secure password storage

		$stmt = $conn->prepare("INSERT INTO users (email, username, password) VALUES (?,?,?)");
		$stmt->bind_param("sss", $email,$username,$password);
			
			
		
		if($stmt->execute()) {
			header("Location: userProfile.php");
			exit();
		} else {
			header("Location: register.php?error-registration-failed");
		}
	}
?>

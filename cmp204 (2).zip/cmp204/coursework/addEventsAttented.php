<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();


include("db_config.php");

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}
    $user_id = $_SESSION['id'];
    $eventName = filter_input(INPUT_POST, 'events_name', FILTER_SANITIZE_STRING);
    $eventVenue = filter_input(INPUT_POST, 'events_venue', FILTER_SANITIZE_STRING);
    $eventDate = filter_input(INPUT_POST, 'events_date', FILTER_SANITIZE_STRING);

    $stmt = $conn->prepare("INSERT INTO events (username, event_name, event_venue, event_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $eventName, $eventVenue, $eventDate);

    if ($stmtInsertEvent->execute()) {
		header("Location: userProfile.php?success=true");
    } else {
        echo "Error adding event: " . $conn->error;
    }

    $stmt->close();

	$conn->close();
?>

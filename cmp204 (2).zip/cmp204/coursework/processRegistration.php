<?php

    //SQL query to insert user to database

    //redirect user back to registration page if unsuccessful, else go to user profile
    //header("Location: http://www.example.com/");

?>
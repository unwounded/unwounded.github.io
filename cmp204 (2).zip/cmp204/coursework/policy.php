<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
	
	<title>Privacy Policy</title>
    <script src="javascript/script.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <?php include_once "includes/links.php" ?>
    </nav>
	<table>
		  <thead>
			<tr>
			  <th class="reqCol">Privacy Policy</th>
			</tr>
		  </thead>

		  <tbody>
				<tr>
				  <td><strong>1. Information We Collect:</strong> If you sign up to use this website's services, we may keep personal information about you. This will include your username, password and email.</td>
				</tr>
				<tr>
				  <td><strong>2. Use of Information:</strong> We would like to use your information to provide better services to you.</td>
				</tr>
				<tr>
				  <td><strong>3. Data Collection:</strong> We would like to collect all order information in our database.</td>
				</tr>
				<tr>
				  <td><strong>4. Data Retention:</strong> Order information is kept to meet legal requirements. Your personal information will be deleted if you do not use this website for a month.</td>
				</tr>
				<tr>
				  <td><strong>5. Contact:</strong> If you have any questions or comments about this privacy policy, or the data collected, please email us at blgfanbase@gmail.com.</td>
				</tr>
		  </tbody>
	</table>
	
	<image src="images/gdpr.png"> </image>
	
	<!-- source: https://vivolead.com/gdpr-eu-security-policy/ --> 
</body>
</html>
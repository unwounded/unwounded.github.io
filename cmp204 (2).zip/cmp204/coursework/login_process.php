<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once "db_config.php";

session_start();
$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
$password = filter_input(INPUT_POST, 'password', FILTER_UNSAFE_RAW); // Assuming password is already hashed on the client side

if (empty($username) || empty($password)) {
    header("Location: login.php?error=empty_fields");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->bind_param("s", $username);

$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        $_SESSION['id'] = $row['id'];
		$_SESSION['username'] = $row['username'];
        if (session_status() == PHP_SESSION_ACTIVE) {
            header("Location: userProfile.php");
            exit();
        } else {
            echo "Error: Session not properly created.";
        }
    } else {
        header("Location: login.php?error=incorrect_password");
        exit();
    }
} else {
    header("Location: login.php?error=user_not_found");
    exit();
}
$stmt->close();
?>
<?php

    //SQL query to insert event to database

    //redirect user back to profile
    //header("Location: http://www.example.com/");

?>
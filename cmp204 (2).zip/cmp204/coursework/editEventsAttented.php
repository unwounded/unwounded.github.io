<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include("db_config.php");


if (!isset($_GET['event_id']) || !is_numeric($_GET['event_id'])) {
    echo "Invalid event ID.";
    exit();
}

$event_id = $_GET['event_id'];
$user_id = $_SESSION['id'];


$stmt = $conn->prepare("SELECT * FROM events WHERE event_name = ? AND username = ?");
$stmt->bind_param("ii", $event_id, $user_id);

$event = [];
if ($stmt->execute()) {
    $result = $stmt->get_result();
    $event = $result->fetch_assoc();
} else {
    echo "Error fetching event data: " . $conn->error;
    exit();
}

$stmt->close();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newEventName = $_POST['events_name'];
    $newEventVenue = $_POST['events_venue'];
    $newEventDate = $_POST['events_date'];

    $stmtUpdateEvent = $conn->prepare("UPDATE events SET events_name = ?, events_venue = ?, events_date = ? WHERE id = ? AND user_id = ?");
    $stmtUpdateEvent->bind_param("sssii", $newEventName, $newEventVenue, $newEventDate, $event_id, $user_id);

    if ($stmtUpdateEvent->execute()) {
        echo "Event updated successfully.";
        header("Location: userProfile.php");
        exit();
    } else {
        echo "Error updating event: " . $conn->error;
    }

    $stmtUpdateEvent->close();
}

$conn->close();
?>

<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include("db_config.php");

if (!isset($_GET['event_id']) || !is_numeric($_GET['event_id'])) {
    echo "Invalid event ID.";
    exit();
}

$event_id = $_GET['event_id'];
$user_id = $_SESSION['id'];

$stmtDeleteEvent = $conn->prepare("DELETE FROM events WHERE id = ? AND username = ?");
$stmtDeleteEvent->bind_param("ii", $event_id, $user_id);

if ($stmtDeleteEvent->execute()) {
    echo "Event deleted successfully.";
} else {
    echo "Error deleting event: " . $conn->error;
}

$stmtDeleteEvent->close();


$conn->close();
?>

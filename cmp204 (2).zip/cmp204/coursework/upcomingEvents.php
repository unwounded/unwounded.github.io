<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Upcoming Events and Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<link rel="stylesheet" href="css/style.css">
    <script src="javascript/upcomingEvents.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <?php include_once "includes/links.php" ?>
    </nav>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6">
                <div class="card match-list">
                    <div class="card-header">
                        <h3 class="card-title">Upcoming Matches</h3>
                        <div class="input-group">
                            <input type="text" class="form-control" id="upcomingMatchInput" placeholder="Add a new match">
                            <button class="btn btn-primary" id="addUpcomingMatch">Add Match</button>
                        </div>
                    </div>
                    <ul class="list-group list-group-flush" id="upcomingMatchesList">
                        <li class="list-group-item">Match 1: Weibo Gaming - Date: 2023-12-15</li>
                        <li class="list-group-item">Match 2: T1 - Date: 2023-12-20</li>
                        <li class="list-group-item">Match 3: Jingdong Gaming - Date: 2023-12-25</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card match-list">
                    <div class="card-header">
                        <h3 class="card-title">Recent Results</h3>
                        <div class="input-group">
							<button class="btn btn-primary" id="showLess">Show Less</button>
							<button class="btn btn-primary" id="showMore">Show More</button>
                        </div>
                    </div>
                    <ul class="list-group list-group-flush" id="recentResultsList">
                        <li class="list-group-item">W: Gen.G - Date: 2023-11-25</li>
                        <li class "list-group-item">W: Fnatic - Date: 2023-11-20</li>
                        <li class="list-group-item">L: Jingdong Gaming - Date: 2023-11-15</li>
                        <li class="list-group-item" id="less">W: NRG - Date: 2023-11-10</li>
                        <li class="list-group-item" id="less2">W: LNG - Date: 2023-11-05</li>
                    </ul>
                </div>
            </div>
        </div>
		<button>More Info</button>
		<p id="evenMoreInfo"></p>
    </div>

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <!-- jQuery library -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>

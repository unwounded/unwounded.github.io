	<table>
	  <thead>
		<tr>
		  <th class="reqCol">Privacy Policy</th>
		</tr>
	  </thead>

	  <tbody>
			<tr>
			  <td><strong>1. Information We Collect:</strong> If you sign up to use this website's services, we may keep personal information about you. This will include your name, home address, email, and phone number.</td>
			</tr>
			<tr>
			  <td><strong>2. Use of Information:</strong> We would like to use your information to provide better services to you, and to show you advertisements from third parties. You can opt in for this purpose.</td>
			</tr>
			<tr>
			  <td><strong>3. Data Collection:</strong> We would like to collect all order information to help us predict global trends. You can opt in for this purpose.</td>
			</tr>
			<tr>
			  <td><strong>4. Data Retention:</strong> Order information is kept to meet legal requirements. Your personal information will be deleted if you do not use this website for a month.</td>
			</tr>
			<tr>
			  <td><strong>5. Contact:</strong> If you have any questions or comments about this privacy policy, or the data collected, please email us at blgfanbase@gmail.com.</td>
			</tr>
	  </tbody>
	</table>

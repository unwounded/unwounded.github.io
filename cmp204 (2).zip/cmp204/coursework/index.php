<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
	<title>Homepage - BiliBili Gaming</title>
	<script src="javascript/index.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <?php include_once "includes/links.php" ?>
    </nav>
	
	
	<main>
		<button id="light">Dark Mode</button>
		<header class="container mt-4">
			<h1>Welcome to BiliBili Gaming Fan Page</h1>
			<p>Celebrating the achievements and passion of BiliBili Gaming</p>
		</header>

		<section class="container mt-4">
			<h2>About BiliBili Gaming</h2>
			<p>BiliBili Gaming is a professional eSports team based in China, known for their excellence in competitive gaming, particularly in League of Legends. This fan page is dedicated to celebrating their victories, exploring their roster, and staying up to date with their latest matches and news.</p>
		</section>

		<section class="container mt-4">
			<h2>Latest Match Highlights</h2>
			<p>Check out the latest exciting moments from BiliBili Gaming's matches!</p>
		</section>
		
		<section class="container mt-4">
			<h2>Fanart</h2>
			<p>Some fan submitted artwork of our players!</p>
		</section>
	</main>

    <!-- jQuery library -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>

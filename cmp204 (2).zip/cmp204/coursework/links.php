<ul class="links">
    <li><a href="index.php">Home</a></li>
    <li><a href="upcomingEvents.php">Upcoming Events</a></li>
    <li><a href="teamMembers.php">Team Members</a></li>
    <li><a href="req.php">Requirements</a></li>

    <!--only show if user is not signed in-->
	<?php if (!isset($_SESSION['id'])) {
		//hide register.php and login.php
	}
		else {
		//hide userProfile.php and logout.php
		}
	?>
    <li><a href="register.php">Register</a></li>
    <li><a href="login.php">Login</a></li>

    <!--only show if authenticated user is signed in-->
    <li><a href="userProfile.php">User Profile</a></li>
    <li><a href="logout.php">Logout</a></li>
	
	
    <li><a href="policy.php">Privacy Policy</a></li>
</ul> 
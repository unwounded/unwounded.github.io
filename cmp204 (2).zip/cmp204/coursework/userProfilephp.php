<?php
// Start or resume a session
session_start();

// Check if the user is logged in
/*if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}*/

// Include the database configuration
include("db_config.php");

// Get the username of the logged-in user
$username = $_SESSION['username'];
$user = [];

$stmt = $conn->prepare("SELECE username FROM users WHERE username = ?");
$stmt->bind_param("i", $username);



// Fetch user data from the database
//$sql = "SELECT * FROM users WHERE username='$username'";
//$result = $conn->query($sql);

if ($stmt->execute()) {
    $result = $stmt->get_result();
	$user = $result->fetch_assoc();
} else {
    // Handle the case where user data is not found
    echo "User not found in the database.";
}

$stmt->close();

$events = [];

// Check if the form is submitted for updating events attended

// Close the database connection
$conn->close();
?>
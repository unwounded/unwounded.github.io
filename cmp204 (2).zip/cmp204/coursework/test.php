<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Information Form</title>
</head>
<body>
	<?php
	// Establish a connection to the MySQL database
	$servername = "lochnagar.abertay.ac.uk"; // replace with your database host
	$username = "sql2301241"; // replace with your database username
	$password = "revised belfast complex nuts"; // replace with your database password
	$dbname = "sql2301241"; // replace with your database name

	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check the connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	// Process the form data
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$game_name = $_POST["game_name"];
		$year_released = $_POST["year_released"];
		$genre = $_POST["genre"];
		$platform = $_POST["platform"];

		// Insert data into the "gamesOne" table
		$sql = "INSERT INTO gamesOne (game_name, year_released, genre, platform) VALUES ('$game_name', $year_released, '$genre', '$platform')";

		if ($conn->query($sql) === TRUE) {
			echo "Record added successfully";
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}

	// Close the database connection
	$conn->close();
	?>
    <h2>Enter Game Information</h2>
    <form action="process_form.php" method="post">
        <label for="game_name">Game Name:</label>
        <input type="text" name="game_name" required><br>

        <label for="year_released">Year Released:</label>
        <input type="number" name="year_released" required><br>

        <label for="genre">Genre:</label>
        <input type="text" name="genre" required><br>

        <label for="platform">Platform:</label>
        <input type="text" name="platform" required><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Team Members</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="javascript/script.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <?php include_once "includes/links.php" ?>
    </nav>
	
    <section class="container mt-4">
        <h2>BiliBili Gaming's Current Roster</h2>
        <table class="table table-bordered table-striped">
            <thead class="thead-light">
                <tr>
                    <th>Position</th>
                    <th>Player</th>
                    <th>Image</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Top Laner</td>
                    <td>Bin</td>
					<!-- source: https://lol.fandom.com/wiki/Bin_(Chen_Ze-Bin) -->
                    <td><img src="images/top_laner.jpg" alt="Bin - Top Laner" class="img-thumbnail"></td>
                </tr>
                <tr>
                    <td>Jungler</td>
                    <td>Xun</td>
					<!-- source: https://lol.fandom.com/wiki/XUN -->
                    <td><img src="images/jungler.jpg" alt="Xun - Jungler" class="img-thumbnail"></td>
                </tr>
                <tr>
                    <td>Mid Laner</td>
                    <td>Yagao</td>
					<!-- source: https://lol.fandom.com/wiki/Yagao -->
                    <td><img src="images/mid_laner.jpg" alt="Yagao - Mid Laner" class="img-thumbnail"></td>
                </tr>
                <tr>
                    <td>AD Carry</td>
                    <td>Elk</td>
					<!-- source: https://lol.fandom.com/wiki/Elk -->
                    <td><img src="images/bot_laner.jpg" alt="Elk - Bot Laner" class="img-thumbnail"></td>
                </tr>
                <tr>
                    <td>Support</td>
                    <td>ON</td>
					<!-- source: https://lol.fandom.com/wiki/ON -->
                    <td><img src="images/support.jpg" alt="ON - Support" class="img-thumbnail"></td>
                </tr>
            </tbody>
        </table>
		
		<button id="clickButton" onclick="loadDoc()">More Info</button>
		<p id="moreInfo"></p>
		
    </section>

    <!-- jQuery library -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>

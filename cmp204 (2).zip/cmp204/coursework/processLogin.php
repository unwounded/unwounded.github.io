<?php

    //SQL query to check if login is a registered user

    //if yes, redirect user to profile, else redirect back to login page
    //header("Location: http://www.example.com/");

?>
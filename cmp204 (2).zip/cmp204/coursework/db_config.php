<?php
session_start();

$servername = "lochnagar.abertay.ac.uk";
$username = "sql2301241";
$password = "revised belfast complex nuts";
$dbname = "sql2301241";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

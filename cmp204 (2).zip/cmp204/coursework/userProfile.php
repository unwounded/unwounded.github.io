<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
 session_start();?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>CMP204 Unit Two Coursework Template</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="javascript/script.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <?php include_once "includes/links.php" ?>
    </nav>
	
	<?php
		include("db_config.php");
		
		if (!isset($_SESSION['id'])) {
			header("Location: login.php");
			exit();
		}

		$user_id = $_SESSION['id'];
		$user = [];

		$stmt = $conn->prepare("SELECT id FROM users WHERE id = ?");
		$stmt->bind_param("i", $user_id);

		if ($stmt->execute()) {
			$result = $stmt->get_result();
			$user = $result->fetch_assoc();
		} else {
			echo "User not found in the database.";
		}

		$stmt->close();

		$events = [];
		$stmtEvents = $conn->prepare("SELECT * FROM events WHERE username = ?");
		$stmtEvents->bind_param("i", $user_id);

		if ($stmtEvents->execute()) {
			$resultEvents = $stmtEvents->get_result();
			while ($row = $resultEvents->fetch_assoc()) {
				$events[] = $row;
			}
		}

		$stmtEvents->close();

		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$eventName = $_POST['events_name'];
			$eventVenue = $_POST['events_venue'];
			$eventDate = $_POST['events_date'];

			$stmtInsertEvent = $conn->prepare("INSERT INTO events (user_id, events_name, events_venue, events_date) VALUES (?, ?, ?, ?)");
			$stmtInsertEvent->bind_param("isss", $user_id, $eventName, $eventVenue, $eventDate);

			if ($stmtInsertEvent->execute()) {
				echo "Event added successfully.";
			} else {
				echo "Error adding event: " . $conn->error;
			}

			$stmtInsertEvent->close();
		}
?>
	
    <div class="container mt-5">
        <h1>User Profile</h1>
        <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
	
		
	    <h3>Events:</h3>
			<ul>
				<?php foreach ($events as $event) : ?>
					<li>
						<?php echo htmlspecialchars($event['events_name']); ?> -
						<?php echo htmlspecialchars($event['events_venue']); ?>,
						<?php echo htmlspecialchars($event['events_date']); ?> |
						<a href="editEventsAttended.php?event_id=<?php echo $event['id']; ?>">Edit</a>
						<a href="deleteEventsAttended.php?event_id=<?php echo $event['id']; ?>">Delete</a>
					</li>
				<?php endforeach; ?>
			</ul>
			<form action="addEventsAttended.php" method="post">
				<label for="events_name">Name of Event:</label>
				<input type="text" name="events_name" required>

				<label for="events_venue">Venue:</label>
				<input type="text" name="events_venue" required>

				<label for="events_date">Date:</label>
				<input type="datetime-local" name="events_date" required>

				<button type="submit">Submit</button>
			</form>
		</div>

    <!-- jQuery library -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>

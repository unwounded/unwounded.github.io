<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Include the database configuration
include("db_config.php");

// Check if the event_id parameter is set in the URL
if (!isset($_GET['event_id']) || !is_numeric($_GET['event_id'])) {
    echo "Invalid event ID.";
    exit();
}

$event_id = $_GET['event_id'];
$user_id = $_SESSION['id'];

// Delete the event from the database
$stmtDeleteEvent = $conn->prepare("DELETE FROM events WHERE id = ? AND user_id = ?");
$stmtDeleteEvent->bind_param("ii", $event_id, $user_id);

if ($stmtDeleteEvent->execute()) {
    echo "Event deleted successfully.";
    // You may want to redirect or go back to the user profile page
} else {
    echo "Error deleting event: " . $conn->error;
}

$stmtDeleteEvent->close();

// Close the database connection
$conn->close();
?>

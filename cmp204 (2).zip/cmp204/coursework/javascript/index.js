window.onload = preparePage;



function preparePage(){
	//find the button
var clickButton=document.getElementById("light");

	//when button clicked, call function
	clickButton.onclick=function(){
		document.body.style.color = "white";
		document.body.style.backgroundColor = "black";
	}

}
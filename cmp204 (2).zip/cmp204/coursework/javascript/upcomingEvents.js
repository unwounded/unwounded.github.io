
$(document).ready(function() {
    $("#addUpcomingMatch").click(function() {
        $("#upcomingMatchesList").append($("<li>").addClass("list-group-item").text($("#upcomingMatchInput").val()));
        $("#upcomingMatchInput").val(''); 
        
    });
}); 

$(document).ready(function(){
  $("#showLess").click(function(){
    $("#less").hide();
	$("#less2").hide();
  });
  $("#showMore").click(function(){
    $("#less").show();
	$("#less2").show();
  });
});

$(document).ready(function(){
	 $("button").click(function(){
		${"#evenMoreInfo").load("more.txt");
	});
});
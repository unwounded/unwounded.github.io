
window.onload = preparePage;

function preparePage(){
	//find the button
var clickButton=document.getElementById("clickButton");

	//when button clicked, call function
	clickButton.onclick=function(){
		loadDoc();
	}

}

function loadDoc() {
	
	var xhttp = new XMLHttpRequest();
	
	xhttp.onreadystatechange = function() {
	
	if (this.readyState == 4 && this.status == 200) {
    	document.getElementById("moreInfo").innerHTML = this.responseText;
    }
  };
  
  xhttp.open("GET", "bin.txt", true);
  
  
  xhttp.send();
}

/*$(document).ready(function(){
	 $("#clickButton2").click(function(){
		${"#evenMoreInfo").load("more.txt");
	});
});*/
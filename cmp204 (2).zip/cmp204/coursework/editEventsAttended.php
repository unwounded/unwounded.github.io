<?php

    //SQL query to update event in database

    //redirect user back to profile
    //header("Location: http://www.example.com/");

?>